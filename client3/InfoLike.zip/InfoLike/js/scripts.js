var year = new Date().getFullYear();

document.getElementById('textcopy').innerHTML = "&copy " + year + " Info Like. Todos os direitos reservados.";

document.getElementById('textcopy2').innerHTML = "&copy " + year + " Info Like. Todos os direitos reservados.";

var largura = window.innerWidth;

  if (largura <= 1000) {
      document.getElementById("titulov").innerHTML = "<h1>Visão</h1>";
      document.getElementById("tituloc").innerHTML = " ";


  } else {
    document.getElementById("titulov").innerHTML = " ";
    document.getElementById("tituloc").innerHTML = "<h1>Visão</h1>";

  }

window.addEventListener('resize', function () {
    //var altura = window.innerHeight;
    largura = window.innerWidth;

    if (largura <= 1000) {
        document.getElementById("titulov").innerHTML = "<h1>Visão</h1>";
        document.getElementById("tituloc").innerHTML = " ";

    } else {
      document.getElementById("titulov").innerHTML = " ";
      document.getElementById("tituloc").innerHTML = "<h1>Visão</h1>";

    }
});
